namespace CellSpace
{
    /// <summary>
    /// 存储XZ坐标的结构体
    /// </summary>
    public struct CellXZInfo
    {
        public int x, z;
    }
}
