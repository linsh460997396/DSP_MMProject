﻿using UnityEngine;
using BepInEx;
using MetalMaxSystem.Unity;
using CellSpace;

namespace MCFramework
{
    [BepInPlugin("com.MCFramework.DSP", "MCFramework_20250821", "1.0.0")]
    public class Main : BaseUnityPlugin
    {
        public GameObject odin;
        public GameObject icarus;
        ExploreSlice exploreSlice;

        //↓入口函数处运用示范↓
        private void Awake()
        {
            //开启一个协程进行资源加载
            AssetBundleLoader.Instance.LoadAllFromMemoryAsync<GameObject>("BepInEx/plugins/MCFramework/abtest");
            //协程结束前尚无法马上取得素材，请等待

            //Unity编辑器中Application.dataPath返回Assets文件夹路径，打包后为应用程序所在路径
            //LoadAllFromMemoryAsync(Application.dataPath + "/AssetBundle/abtest");
        }

        private void Start()
        {
            if (AssetBundleLoader.currentObjectGroup != null)
            {
                Debug.Log("AssetBundleLoader.currentObjectGroup.Length => " + AssetBundleLoader.currentObjectGroup.Length.ToString());
                for (int i = 0; i < AssetBundleLoader.currentObjectGroup.Length; i++)
                {
                    Debug.Log("读取AB包中第" + i.ToString() + "个元素成功！");
                    Debug.Log("GameObject " + i + " Name: " + AssetBundleLoader.currentObjectGroup[i].name);
                }
            }
            exploreSlice = new ExploreSlice();
            Debug.Log("挂载ExploreSlice模型爆炸功能！");
            CPEngine.Active();
            Debug.Log("激活MC框架");
        }

        private void Update()
        {
            #region 外部模型导入

            if (Input.GetKeyDown(KeyCode.PageDown))
            {
                icarus = GameObject.Find("Player (Icarus 1)");
                CPEngine.ChunkCreationIndicator = icarus.transform;
                CPEngine.Tick();
                Debug.Log("CPEngine.Tick()");
            }

            if (Input.GetKeyDown(KeyCode.Q))
            {
                Debug.Log("按下了Q键");

                //实例化资源中第一个游戏物体（前提是资源已经在协程里加载完毕，这里要进行检查）
                if (AssetBundleLoader.currentObjectGroup != null)
                {
                    icarus = GameObject.Find("Player (Icarus 1)");
                    CPEngine.ChunkCreationIndicator = icarus.transform;

                    if (icarus != null)
                    {
                        //gameObjectGroup[0]是奥丁，gameObjectGroup[1]是跳虫，目前AB包（abtest）内这只有2个预制体。
                        odin = Instantiate(AssetBundleLoader.currentObjectGroup[0] as GameObject);
                        Debug.Log("奥丁已创建");
                    }

                    //检测动画剪辑
                    Animation[] animations = odin.GetComponents<Animation>();
                    foreach (Animation animation in animations)
                    {
                        Debug.Log("odinAnimation Name: " + animation.name);
                        Debug.Log("odinCurrentAnimationClip Name: " + animation.clip.name);
                    }

                    //删除预制体内的刚体，防止子物体参与物理引擎，让子模型完全按主体的Transform行动
                    Rigidbody odinRigidbody = odin.GetComponent<Rigidbody>();
                    if (odinRigidbody != null)
                    {
                        Destroy(odinRigidbody);
                    }

                    #region 对游戏物体进行镭射检测并输出碰撞到的物体名

                    // 在 mainPlayer 游戏对象周围指定半径内检测游戏对象
                    Debug.Log("对周围10.0半径内的游戏对象进行镭射检测...");
                    LayerMask layerMask = ~0;
                    Collider[] hits = Physics.OverlapSphere(GameMain.mainPlayer.transform.position, 10.0f, layerMask);
                    // 输出检测到的游戏对象的名称
                    foreach (Collider hit in hits)
                    {
                        //得到游戏对象
                        GameObject hitObject = hit.gameObject;
                        Debug.Log("检测到游戏对象: " + hitObject.name);
                    }

                    #endregion

                    #region 衔接

                    //衔接前游戏物体的世界坐标系的旋转和位置与要衔接的主体保持一致
                    odin.transform.localPosition = GameMain.mainPlayer.transform.localPosition;
                    odin.transform.localRotation = GameMain.mainPlayer.controller.model.localRotation;

                    //将odin设置为mainPlayer的子对象（直接拼装了，比下方的每帧修正更省事）
                    odin.transform.parent = GameMain.mainPlayer.transform;
                    Debug.Log("奥丁已拼接到mainPlayer");
                    //给odin添加刚体组件
                    //Rigidbody odinRigidbody = odin.AddComponent<Rigidbody>();

                    #endregion
                }
                else { Debug.Log("协程未完成！依然读取AB包中..."); }
            }
            #endregion

            #region 行走动画

            if (odin != null && (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.D)))
            {
                odin.GetComponent<Animation>().Play("Walk");
            }

            #endregion

            #region 自动旋转

            if (odin != null)
            {
                // 将旋转四元数应用到odin的局部旋转上
                odin.transform.localRotation = GameMain.mainPlayer.controller.model.localRotation;
            }

            #endregion

            #region 爆破功能

            if (odin != null && Input.GetMouseButtonDown(0))
            {
                // 获取鼠标点击的屏幕坐标
                Vector3 mousePos = Input.mousePosition;
                Vector3 rayOrigin = Camera.main.transform.position; // 射线的起点：摄像机位置
                Vector3 rayDirection = Camera.main.ScreenPointToRay(mousePos).direction; // 射线的方向：从摄像机到鼠标点击

                // 投射射线
                Ray ray = new Ray(rayOrigin, rayDirection);
                RaycastHit hit;
                float rayLength = 10000f; // 射线的长度，可以根据需要调整
                //LayerMask layerMask = LayerMask.GetMask("Default"); // 射线投射的目标层
                LayerMask layerMask = ~0;

                if (Physics.Raycast(ray, out hit, rayLength, layerMask))
                {
                    // 射线击中了物体
                    Debug.Log("Hit object: " + hit.transform.name);
                    if (hit.transform.gameObject.GetComponent<DrawBounds>() == null)
                    {
                        hit.transform.gameObject.AddComponent<DrawBounds>();
                        Debug.Log("挂载爆破功能: " + hit.transform.name);
                    }


                    exploreSlice.Explore(hit.transform.gameObject, ray.direction);
                }
                else
                {
                    // 射线没有击中任何物体
                    Debug.Log("No object hit");
                    // 使用Debug.DrawRay在Scene视图中绘制射线
                    Debug.DrawRay(rayOrigin, rayDirection * rayLength, Color.red, 0.5f); // 红色射线，持续0.5秒
                }
            }

            #endregion
        }
    }
}
